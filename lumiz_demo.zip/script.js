const products = [
  { id: 1, name: "Smartphone", price: 299.99, image: "https://picsum.photos/200?1" },
  { id: 2, name: "Laptop", price: 799.99, image: "https://picsum.photos/200?2" },
  { id: 3, name: "Headphones", price: 59.99, image: "https://picsum.photos/200?3" },
  { id: 4, name: "Washing Machine", price: 499.99, image: "https://picsum.photos/200?4" },
  { id: 5, name: "Toy Car", price: 19.99, image: "https://picsum.photos/200?5" },
  { id: 6, name: "Shoes", price: 49.99, image: "https://picsum.photos/200?6" }
];

const grid = document.getElementById("product-grid");
const cartBtn = document.getElementById("cart-btn");
const cartModal = document.getElementById("cart-modal");
const closeCart = document.getElementById("close-cart");
const cartItems = document.getElementById("cart-items");
const cartCount = document.getElementById("cart-count");
const cartTotal = document.getElementById("cart-total");
const checkoutBtn = document.getElementById("checkout-btn");
const checkoutModal = document.getElementById("checkout-modal");
const closeCheckout = document.getElementById("close-checkout");
const searchInput = document.getElementById("search");

let cart = [];

function renderProducts(items) {
  grid.innerHTML = "";
  items.forEach(p => {
    const div = document.createElement("div");
    div.className = "product";
    div.innerHTML = \`
      <img src="\${p.image}" alt="\${p.name}">
      <h3>\${p.name}</h3>
      <p>$\${p.price.toFixed(2)}</p>
      <button onclick="addToCart(\${p.id})">Add to Cart</button>
    \`;
    grid.appendChild(div);
  });
}

function addToCart(id) {
  const product = products.find(p => p.id === id);
  cart.push(product);
  updateCart();
}

function updateCart() {
  cartItems.innerHTML = "";
  let total = 0;
  cart.forEach((item, index) => {
    total += item.price;
    const li = document.createElement("li");
    li.textContent = \`\${item.name} - $\${item.price.toFixed(2)}\`;
    cartItems.appendChild(li);
  });
  cartCount.textContent = cart.length;
  cartTotal.textContent = total.toFixed(2);
}

cartBtn.onclick = () => cartModal.classList.remove("hidden");
closeCart.onclick = () => cartModal.classList.add("hidden");
checkoutBtn.onclick = () => {
  cartModal.classList.add("hidden");
  checkoutModal.classList.remove("hidden");
};
closeCheckout.onclick = () => checkoutModal.classList.add("hidden");

document.getElementById("checkout-form").onsubmit = (e) => {
  e.preventDefault();
  alert("Order placed successfully!");
  cart = [];
  updateCart();
  checkoutModal.classList.add("hidden");
};

searchInput.addEventListener("input", (e) => {
  const term = e.target.value.toLowerCase();
  const filtered = products.filter(p => p.name.toLowerCase().includes(term));
  renderProducts(filtered);
});

renderProducts(products);
