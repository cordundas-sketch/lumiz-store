# Lumi-Z Store

This is a demo e-commerce site for **Lumi-Z**.

## How to deploy on GitHub Pages

1. Create a new repository on GitHub.
2. Upload these files to the root of the repository.
3. Go to **Settings > Pages** and select branch = `main`, folder = `/ (root)`.
4. Wait a few minutes, then access your site at:
   `https://yourusername.github.io/repo-name/`
